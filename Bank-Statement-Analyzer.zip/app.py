import streamlit as st

st.set_page_config(page_title="Bank Statement Analyzer", layout="wide")
st.title("🏦 Bank Statement Management System")
st.write("Application setup successful ✅")
